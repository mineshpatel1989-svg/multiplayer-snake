# 🐍 Multiplayer Snake (Server + Client)

## Run locally
```bash
npm install
npm start
# open http://localhost:3000
```

## Deploy (Render.com quick setup)
- Build: `npm install`
- Start: `npm start`
- Free tier works. You get HTTPS URL like https://yourapp.onrender.com
